#!/usr/bin/env python3
"""Ten sequential, fresh-output binding checks using the accepted portable build."""
from pathlib import Path
import datetime, hashlib, json, os, re, subprocess, sys, time, traceback

WORK = Path(__file__).resolve().parent
REPO = Path('/Users/milostatarevic/programming/projects/ramsey-diagonal/r77-findings/r3333-upper-bound')
FORMAL = REPO/'formal'
PORTABLE = Path('/Users/milostatarevic/programming/projects/ramsey/r3333-review/ramsey61-portable-build-20260923/formal')
BUILD = PORTABLE/'.build/runs/20260923T064238.332922Z_ddf40e3c'
ARCHIVE = Path('/private/tmp/ramsey61-public-release-check-20260921-001')
EXPECTED = '15b6775769f3578acd5c6aa22c46506decb3c041bd98912a79d50dd6e55ea8ed'
PYTHON = '/usr/bin/python3'
STARTED = datetime.datetime.now(datetime.timezone.utc).isoformat()
START_MONO = time.monotonic()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def pin(p):
    p = Path(p)
    return {'path':str(p), 'bytes':p.stat().st_size, 'sha256':digest(p)}

def save(p, obj):
    with Path(p).open('x') as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write('\n')
    Path(p).chmod(0o444)

def outputs():
    rows=[]
    for p in sorted((WORK/'outputs').rglob('*')):
        if p.is_file():
            row=pin(p); row['path']=str(p.relative_to(WORK)); rows.append(row)
    return rows

def freeze_outputs():
    for root in [WORK/'outputs', WORK/'steps']:
        if root.exists():
            for p in root.rglob('*'):
                if p.is_file():p.chmod(0o444)

steps=[]
precheck=None
try:
    for child in ['outputs','steps']:
        (WORK/child).mkdir()
    manifest_path=FORMAL/'SOURCE_MANIFEST.json'
    assert digest(manifest_path)==EXPECTED
    assert (PORTABLE/'SOURCE_MANIFEST.json').read_bytes()==manifest_path.read_bytes()
    manifest=json.loads(manifest_path.read_text())
    build_result=json.loads((BUILD/'BUILD_RESULT.json').read_text())
    assert build_result['status']=='PASS' and build_result['manifest_sha256']==EXPECTED
    assert build_result['baseline_project_artifacts_reused'] is False
    assert len(build_result['completed'])==1809 and not build_result['failures'] and not build_result['pending']
    compiler=build_result['compiler']['path']
    assert digest(compiler)==build_result['compiler']['sha256']
    reference=json.loads((BUILD/'modules/Ramsey61.Selector/receipt.json').read_text())
    lean_path=reference['LEAN_PATH'].split(':')
    assert lean_path[0]==str(BUILD/'lib')
    assert all(Path(p).is_dir() for p in lean_path)
    assert all(str(PORTABLE/'.lake/packages') in p or p==str(BUILD/'lib') or p==str(Path(compiler).parent.parent/'lib/lean') for p in lean_path)
    project=[]
    for name, source in sorted(manifest['modules'].items()):
        source_path=FORMAL/source['path']; portable_source=PORTABLE/source['path']
        assert digest(source_path)==source['sha256'] and digest(portable_source)==source['sha256'],name
        rec_path=BUILD/'modules'/name/'receipt.json';rec=json.loads(rec_path.read_text())
        artifact=BUILD/'lib'/Path(*name.split('.')).with_suffix('.olean')
        assert rec['status']=='PASS' and rec['exit_code']==0 and rec['source']==source,name
        assert rec['compiler_sha256']==build_result['compiler']['sha256'],name
        assert artifact.stat().st_size==rec['artifact_bytes'] and digest(artifact)==rec['artifact_sha256'],name
        project.append({'module':name,'source':pin(source_path),'portable_source':str(portable_source),'artifact':pin(artifact),'receipt':pin(rec_path)})
    assert len(project)==1809
    payload=[]
    for entry in manifest['files']+manifest['data']:
        p=FORMAL/entry['path'];assert digest(p)==entry['sha256'],str(p);payload.append(pin(p))
    tool_relatives=['d/Emit.lean','d/verify.py','d/path_index.json','common/Emit.lean','common/verify.py','common/path_index.json','common/lean/PricingABD/CommonSuffixCache.lean','uuq/EmitUUQ.lean','uuq/compare.py','uuq/reference_index.json','c/Emit.lean','c/verify.py','c/path_index.json','c/EmitBase.lean','c/checks/original_base_comparison.json']
    common_index=json.loads((FORMAL/'reproduce/common/path_index.json').read_text())
    tool_relatives += ['common/'+row['path'] for row in common_index['records'].values()]
    tool_paths={FORMAL/'reproduce'/relative for relative in tool_relatives}
    tool_paths.update(REPO/'publication/checks/C_BASE_BINDING_001'/name for name in ['EmitBase.lean','compare_base.py'])
    tool_pins=[pin(p) for p in sorted(tool_paths)]
    emitters=['formal/reproduce/d/Emit.lean','formal/reproduce/common/Emit.lean','formal/reproduce/uuq/EmitUUQ.lean','publication/checks/C_BASE_BINDING_001/EmitBase.lean','formal/reproduce/c/Emit.lean']
    closure_rows=[]
    all_external=set()
    for relative in emitters:
        direct=re.findall(r'^import\s+(\S+)',(REPO/relative).read_text(),re.M)
        seen=set();external=set();todo=list(direct)
        while todo:
            module=todo.pop()
            if module in seen or module in external:continue
            if module not in manifest['modules']:
                external.add(module);continue
            seen.add(module);todo.extend(manifest['modules'][module]['imports'])
        closure_rows.append({'emitter':pin(REPO/relative),'direct_imports':direct,'project_modules':sorted(seen),'external_imports':sorted(external)})
        all_external.update(external)
    external_pins=[]
    for name in sorted(all_external):
        candidates=[Path(p)/Path(*name.split('.')).with_suffix('.olean') for p in lean_path[1:]]
        matches=[p for p in candidates if p.is_file()]
        assert matches,('missing external import',name)
        external_pins.append({'module':name,'resolved_artifact':pin(matches[0])})
    env={'HOME':str(Path.home()),'PATH':'/usr/bin:/bin:/usr/sbin:/sbin','LANG':'C','LC_ALL':'C','LEAN_PATH':reference['LEAN_PATH']}
    precheck={'schema':'RAMSEY_CURRENT_BINDING_PRECHECK_1','status':'PASS','completed_utc':now(),'source_manifest':pin(manifest_path),'portable_source_manifest':pin(PORTABLE/'SOURCE_MANIFEST.json'),'portable_build_result':pin(BUILD/'BUILD_RESULT.json'),'compiler':pin(compiler),'python':pin(PYTHON),'controller':pin(__file__),'toolchain':manifest['toolchain'],'dependency_revisions':build_result['compiler']['packages'],'environment':env,'project_module_count':1809,'project_modules':project,'manifest_control_and_data_files':payload,'current_public_tool_bundle':tool_pins,'emitter_import_closures':closure_rows,'external_direct_import_artifacts':external_pins,'archive':str(ARCHIVE),'archive_c_base':pin(ARCHIVE/'evidence/c_campaign/inputs/BROAD_BASE_001.cnf'),'scope':'All 1809 current source hashes and all 1809 portable project artifacts authenticated against accepted manifest and successful module receipts. Recorded portable dependency library paths only; no old classification baseline.'}
    save(WORK/'PRECHECK.json',precheck)
    print('PRECHECK PASS: 1809 current sources and portable artifacts authenticated',flush=True)
    out=WORK/'outputs'
    def emit(label,rel,destination):
        return (label,[compiler,'-j1','--run',str(REPO/rel),str(out/destination)])
    def check(label,rel,args):
        return (label,[PYTHON,'-I','-B',str(REPO/rel),*map(str,args)])
    specs=[
      emit('01_D_EMIT','formal/reproduce/d/Emit.lean','d'),
      check('02_D_BIND','formal/reproduce/d/verify.py',['--archive-dir',ARCHIVE,'--d-prefix-dir',out/'d','--output-dir',out/'d_check']),
      emit('03_COMMON_EMIT','formal/reproduce/common/Emit.lean','common'),
      check('04_COMMON_BIND','formal/reproduce/common/verify.py',['--package-root',FORMAL/'reproduce/common','--archive-root',ARCHIVE,'--emission-root',out/'common','--d-prefix-dir',out/'d','--output-dir',out/'common_check']),
      emit('05_UUQ_EMIT','formal/reproduce/uuq/EmitUUQ.lean','uuq'),
      check('06_UUQ_BIND','formal/reproduce/uuq/compare.py',['--archive-dir',ARCHIVE,'--emission-dir',out/'uuq','--d-prefix-dir',out/'d','--output-dir',out/'uuq_check']),
      emit('07_C_BASE_EMIT','publication/checks/C_BASE_BINDING_001/EmitBase.lean','BROAD_BASE_FROM_LEAN.cnf'),
      check('08_C_BASE_BIND','publication/checks/C_BASE_BINDING_001/compare_base.py',['--archived',ARCHIVE/'evidence/c_campaign/inputs/BROAD_BASE_001.cnf','--emitted',out/'BROAD_BASE_FROM_LEAN.cnf','--output',out/'c_base_comparison.json']),
      emit('09_C_EMIT','formal/reproduce/c/Emit.lean','c'),
      check('10_C_BIND','formal/reproduce/c/verify.py',['--archive-dir',ARCHIVE,'--emission-dir',out/'c','--base-file',out/'BROAD_BASE_FROM_LEAN.cnf','--output-dir',out/'c_check']),
    ]
    save(WORK/'PLAN.json',{'schema':'RAMSEY_CURRENT_BINDING_PLAN_1','created_utc':now(),'cwd':str(FORMAL),'environment':env,'steps':[{'label':label,'argv':argv} for label,argv in specs],'new_solver_calls':0,'certificate_replays':0,'project_compilation':False})
    for label,argv in specs:
        record_dir=WORK/'steps'/label;record_dir.mkdir();log=record_dir/'combined.log'
        before=now();mono=time.monotonic()
        with log.open('xb') as stream:
            process=subprocess.Popen(argv,cwd=FORMAL,env=env,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT)
            pid,status,usage=os.wait4(process.pid,0)
            rc=os.waitstatus_to_exitcode(status);process.returncode=rc
        receipt={'schema':'RAMSEY_CURRENT_BINDING_STEP_1','label':label,'status':'PASS' if rc==0 else 'FAIL','started_utc':before,'finished_utc':now(),'elapsed_seconds':time.monotonic()-mono,'pid':pid,'exit_code':rc,'wait4_status':status,'user_CPU_seconds':usage.ru_utime,'system_CPU_seconds':usage.ru_stime,'CPU_seconds':usage.ru_utime+usage.ru_stime,'peak_RSS_bytes_macos':usage.ru_maxrss,'argv':argv,'cwd':str(FORMAL),'environment':env,'precheck':pin(WORK/'PRECHECK.json'),'executable':pin(argv[0]),'log':pin(log),'new_solver_calls':0,'certificate_replays':0}
        save(record_dir/'receipt.json',receipt);log.chmod(0o444);steps.append(receipt)
        print(label,receipt['status'],'CPU',round(receipt['CPU_seconds'],3),'elapsed',round(receipt['elapsed_seconds'],3),'RSS',receipt['peak_RSS_bytes_macos'],flush=True)
        assert rc==0,('step failed',label,rc,str(log))
    d=json.loads((out/'d_check/receipt.json').read_text());common=json.loads((out/'common_check/COMMON_NATIVE_ALL_INPUT_BINDING.json').read_text());uuq=json.loads((out/'uuq_check/BINDING.json').read_text());cbase=json.loads((out/'c_base_comparison.json').read_text());c=json.loads((out/'c_check/receipt.json').read_text())
    assert d['status']=='PASS_ALL_TWELVE_NATIVE_D_BASES'
    assert common['status']=='PASS_ALL_55016_COMMON_NATIVE_INPUTS' and common['complete_native_inputs']==55016
    assert uuq['status']=='PASS' and uuq['cases']==1358
    assert cbase['status']=='PASS' and cbase['clauses_compared']==1880888
    assert c['status']=='PASS_ALL_456_NATIVE_C_INPUT_IDENTITIES' and c['cases']==456
    assert digest(manifest_path)==EXPECTED and digest(compiler)==precheck['compiler']['sha256']
    for row in tool_pins:assert digest(row['path'])==row['sha256'],('tool drift',row['path'])
    for row in project:assert digest(row['source']['path'])==row['source']['sha256'],('source drift',row['module'])
    output_rows=outputs();save(WORK/'OUTPUT_CHECKSUMS.json',{'files':output_rows,'file_count':len(output_rows),'logical_bytes':sum(row['bytes'] for row in output_rows)})
    result={'schema':'RAMSEY_PUBLISHED_INPUT_BINDINGS_RUN_1','status':'PASS','started_utc':STARTED,'finished_utc':now(),'elapsed_seconds_including_preflight':time.monotonic()-START_MONO,'steps_elapsed_seconds':sum(row['elapsed_seconds'] for row in steps),'CPU_seconds':sum(row['CPU_seconds'] for row in steps),'joined_binding_CPU_seconds':sum(row['CPU_seconds'] for row in steps if '_C_BASE_' not in row['label']),'c_base_CPU_seconds':sum(row['CPU_seconds'] for row in steps if '_C_BASE_' in row['label']),'peak_single_step_RSS_bytes':max(row['peak_RSS_bytes_macos'] for row in steps),'source_manifest_sha256':EXPECTED,'portable_build_run':str(BUILD),'project_artifacts_authenticated':1809,'cases':{'common':55016,'UUQ':1358,'C':456,'total':56830},'D_prefixes':12,'C_base_bytes':(out/'BROAD_BASE_FROM_LEAN.cnf').stat().st_size,'C_base_sha256':digest(out/'BROAD_BASE_FROM_LEAN.cnf'),'C_retained_records':c['retained_records'],'C_record_status_counts':c['record_status_counts'],'new_solver_calls':0,'certificate_replays':0,'project_modules_rebuilt':0,'precheck':pin(WORK/'PRECHECK.json'),'plan':pin(WORK/'PLAN.json'),'output_checksums':pin(WORK/'OUTPUT_CHECKSUMS.json'),'output_file_count':len(output_rows),'output_logical_bytes':sum(row['bytes'] for row in output_rows),'checks':{'D':d['status'],'common':common['status'],'UUQ':uuq['status'],'C_base':cbase['status'],'C':c['status']},'steps':[{'label':row['label'],'CPU_seconds':row['CPU_seconds'],'elapsed_seconds':row['elapsed_seconds'],'peak_RSS_bytes_macos':row['peak_RSS_bytes_macos'],'receipt':pin(WORK/'steps'/row['label']/'receipt.json')} for row in steps],'scope':'Current public emitters and comparators run sequentially against exact accepted portable library. C check uses the freshly emitted and compared base. Native solver answers remain computational evidence; this run performs no solving or certificate replay.'}
    save(WORK/'RUN_RESULT.json',result);freeze_outputs()
    print(json.dumps({k:v for k,v in result.items() if k not in ['steps','checks','scope','precheck','plan','output_checksums']},indent=2),flush=True)
except BaseException as error:
    failure={'schema':'RAMSEY_PUBLISHED_INPUT_BINDINGS_RUN_1','status':'FAIL','started_utc':STARTED,'finished_utc':now(),'error':repr(error),'traceback':traceback.format_exc(),'completed_steps':steps,'new_solver_calls':0,'certificate_replays':0}
    if not (WORK/'RUN_RESULT.json').exists():save(WORK/'RUN_RESULT.json',failure)
    freeze_outputs();print(traceback.format_exc(),flush=True);raise
